# 📋 ПОШАГОВОЕ РУКОВОДСТВО - Как использовать AmoCRM с ChatGPT

## 🚀 БЫСТРЫЙ СТАРТ (5 минут)

### ШАГ 1: Запуск локального сервера ⚡

```bash
# Открой Терминал и выполни:
cd ~/Projects/mcp-amocrm-server
./start_amocrm_server.sh
```

**Результат:** Сервер запустится на `http://127.0.0.1:8000`

### ШАГ 2: Настройка Custom GPT в ChatGPT 🤖

1. **Открой ChatGPT:** [chat.openai.com](https://chat.openai.com)
2. **Создай Custom GPT:** Нажми на свой профиль → "My GPTs" → "Create a GPT"
3. **Скопируй инструкции:** Открой файл `CHATGPT_SETUP.md` и скопируй текст из раздела "Instructions"
4. **Вставь в GPT Builder:** Перейди на вкладку "Configure" → поле "Instructions"
5. **Настрой Actions:**
   - Перейди на вкладку "Actions" 
   - Нажми "Create new action"
   - Скопируй JSON из файла `chatgpt_demo_schema.json`
   - **ВАЖНО:** Замени `YOUR_DEPLOYED_URL_HERE` на `127.0.0.1:8000`

### ШАГ 3: Тестирование 🧪

В созданном Custom GPT напиши:
- **"Покажи статус AmoCRM сервера"**
- **"Получи 3 последние сделки"**

---

## 🌐 ПУБЛИЧНЫЙ ДОСТУП (для постоянной работы)

Если хочешь, чтобы ChatGPT работал всегда:

### Вариант A: Render.com (рекомендуется) 

1. **Перейди на:** [render.com](https://render.com)
2. **Зарегистрируйся** (бесплатно)
3. **Нажми:** "New" → "Web Service"
4. **Выбери:** "Build and deploy from a Git repository"
5. **Подключи GitHub:** Выбери репозиторий `Garrik24/mcp-amocrm-server`
6. **Настройки:**
   - Name: `amocrm-server`
   - Build Command: `pip install -r requirements.txt`
   - Start Command: `uvicorn app:app --host 0.0.0.0 --port $PORT`
7. **Deploy:** Нажми "Create Web Service"

**Получишь URL:** `https://amocrm-server.onrender.com`

### Вариант B: Railway.app

1. **Перейди на:** [railway.app](https://railway.app)  
2. **"New Project"** → "Deploy from GitHub repo"
3. **Выбери:** `Garrik24/mcp-amocrm-server`
4. **Deploy** происходит автоматически

### ШАГ 4: Обновление ChatGPT Schema

После деплоя:
1. Открой свой Custom GPT → "Configure" → "Actions"
2. Замени `127.0.0.1:8000` на твой реальный URL
3. Сохрани изменения

---

## 🔧 НАСТРОЙКА CLAUDE DESKTOP

### ШАГ 1: Проверь конфигурацию

Файл уже создан: `/Users/makbuk/Library/Application Support/Claude/claude_desktop_config.json`

### ШАГ 2: Перезапуск Claude Desktop

1. **Полностью закрой** Claude Desktop
2. **Открой заново**
3. **Проверь подключение:** Должен появиться значок 🔌

### ШАГ 3: Тестирование в Claude

Напиши в Claude Desktop:
- **"Покажи статус AmoCRM сервера"**
- **"Получи информацию об аккаунте"**

---

## ⚙️ НАСТРОЙКА AMOCRM (если нужно)

### ШАГ 1: Получение токенов AmoCRM

1. **Войди в AmoCRM:** Твой поддомен: `stavgeo26.amocrm.ru`
2. **Настройки → Интеграции**
3. **Создай интеграцию** или используй существующую
4. **Получи:**
   - Client ID
   - Client Secret  
   - Access Token

### ШАГ 2: Обновление .env файла

```bash
# Отредактируй файл:
nano ~/Projects/mcp-amocrm-server/.env

# Добавь реальные данные:
AMOCRM_CLIENT_ID=твой_client_id
AMOCRM_CLIENT_SECRET=твой_secret
AMOCRM_SUBDOMAIN=stavgeo26
AMOCRM_ACCESS_TOKEN=твой_токен
```

### ШАГ 3: Перезапуск сервера

```bash
# Останови сервер (Ctrl+C) и запусти заново:
cd ~/Projects/mcp-amocrm-server
./start_amocrm_server.sh
```

---

## 📱 ПРИМЕРЫ ИСПОЛЬЗОВАНИЯ

### В ChatGPT Custom GPT:

```
"Создай сделку 'Новый клиент' с бюджетом 100000 рублей"
"Покажи последние 5 сделок"
"Найди контакты в AmoCRM"
"Сделай отчет по продажам за месяц"
```

### В Claude Desktop:

```
"Получи статус AmoCRM сервера"
"Покажи информацию об аккаунте"  
"Создай новую сделку"
```

---

## 🆘 УСТРАНЕНИЕ ПРОБЛЕМ

### Сервер не запускается:
```bash
cd ~/Projects/mcp-amocrm-server
source venv/bin/activate
pip install -r requirements.txt
python app.py
```

### ChatGPT не подключается:
- Проверь, что сервер работает: `curl http://127.0.0.1:8000`
- Проверь URL в Actions Schema
- Убедись, что сервер доступен извне (для публичного деплоя)

### Claude Desktop не видит MCP:
- Перезапусти Claude Desktop полностью
- Проверь файл конфигурации
- Убедись, что сервер запущен

### AmoCRM ошибки:
- Проверь токены в .env файле
- Убедись, что интеграция активна в AmoCRM
- Проверь права доступа

---

## 🎯 ИТОГОВАЯ СХЕМА

```
AmoCRM ←→ Твой сервер ←→ ChatGPT Custom GPT
    ↑         ↓
    └─────→ Claude Desktop (MCP)
```

**Готово! Теперь у тебя полная автоматизация AmoCRM через ИИ! 🚀**

