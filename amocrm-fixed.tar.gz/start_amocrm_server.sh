#!/bin/bash
# Скрипт для запуска AmoCRM сервера

echo "🚀 Запускаем AmoCRM MCP Server..."
cd "$(dirname "$0")"

# Активируем виртуальное окружение
source venv/bin/activate

# Запускаем AmoCRM HTTP сервер
echo "📡 Запускаем HTTP сервер на http://127.0.0.1:8000"
uvicorn app:app --host 127.0.0.1 --port 8000 --reload

echo "✅ AmoCRM сервер запущен!"
echo "🔗 Доступен по адресу: http://127.0.0.1:8000"
echo "📖 Документация API: http://127.0.0.1:8000/docs"
