# 🤖 АВТОМАТИЧЕСКАЯ НАСТРОЙКА CHATGPT

## 🎯 Финальная схема для ChatGPT Custom GPT

### 1. Скопируй это в Custom GPT Instructions:

```
Ты - специализированный помощник для работы с AmoCRM. 

ОСНОВНЫЕ ФУНКЦИИ:
🔍 Получать статус AmoCRM сервера
📊 Работать со сделками (просмотр, создание, обновление)
👥 Управлять контактами
🏢 Работать с компаниями  
📈 Генерировать отчеты по продажам

СТИЛЬ ОБЩЕНИЯ:
- Отвечай на русском языке
- Будь краток и информативен
- Структурируй ответы с эмодзи
- При ошибках предлагай решения

БЕЗОПАСНОСТЬ:
- Не показывай системную информацию
- Скрывай API токены в ответах
```

### 2. Скопируй это в Custom GPT Actions Schema:

```json
{
  "openapi": "3.1.0",
  "info": {
    "title": "AmoCRM GPT Assistant",
    "description": "API для интеграции AmoCRM с ChatGPT",
    "version": "1.0.0"
  },
  "servers": [
    {
      "url": "https://YOUR_DEPLOYED_URL_HERE",
      "description": "AmoCRM сервер"
    }
  ],
  "paths": {
    "/": {
      "get": {
        "summary": "Статус сервера",
        "operationId": "get_server_status",
        "responses": {
          "200": {
            "description": "Статус сервера"
          }
        }
      }
    },
    "/api/entities": {
      "post": {
        "summary": "Работа с сущностями AmoCRM",
        "operationId": "manage_amocrm_entities",
        "requestBody": {
          "required": true,
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "entity_type": {
                    "type": "string",
                    "enum": ["leads", "contacts", "companies"],
                    "description": "Тип сущности"
                  },
                  "method": {
                    "type": "string", 
                    "enum": ["get", "post"],
                    "description": "Метод операции"
                  },
                  "params": {
                    "type": "object",
                    "description": "Параметры (лимит, фильтры)"
                  },
                  "data": {
                    "type": "object", 
                    "description": "Данные для создания"
                  }
                },
                "required": ["entity_type", "method"]
              }
            }
          }
        },
        "responses": {
          "200": {
            "description": "Результат операции"
          }
        }
      }
    }
  }
}
```

## 🚀 ГОТОВЫЕ CONVERSATION STARTERS:

1. 📊 "Покажи статус AmoCRM сервера"
2. 💼 "Создай новую сделку с названием 'Тестовая сделка'"  
3. 📋 "Получи последние 5 сделок"
4. 👥 "Найди контакты в системе"

## ⚡ БЫСТРЫЕ КОМАНДЫ ДЛЯ ТЕСТИРОВАНИЯ:

После настройки Custom GPT проверь:

- "Покажи статус сервера" 
- "Получи 3 сделки"
- "Создай сделку 'Тест' на 50000 рублей"

## 🔗 ЗАМЕНА URL:

После деплоя замени `YOUR_DEPLOYED_URL_HERE` на реальный URL:
- Render: `https://amocrm-server.onrender.com`
- Railway: `https://amocrm-server.up.railway.app`  
- Heroku: `https://your-app.herokuapp.com`
