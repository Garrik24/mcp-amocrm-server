# 🚀 Пошаговая настройка Custom GPT для AmoCRM

## Вариант 1: Локальное подключение (простой)

### 1. Запуск сервера
```bash
cd ~/Projects/mcp-amocrm-server
./start_amocrm_server.sh
```

### 2. Создание Custom GPT
1. Перейди на [ChatGPT Custom GPTs](https://chat.openai.com/gpts/editor)
2. Нажми **"Create a GPT"**
3. В разделе **Instructions** вставь содержимое файла `chatgpt_instructions.md`

### 3. Настройка Actions
1. Перейди на вкладку **"Actions"**
2. Нажми **"Create new action"**
3. В поле **Schema** вставь содержимое файла `chatgpt_openapi.json`
4. В Schema замени `YOUR_NGROK_URL_HERE.ngrok.io` на `127.0.0.1:8000`

⚠️ **Ограничение:** Работает только если ChatGPT и сервер в одной сети

---

## Вариант 2: Публичный доступ (рекомендуемый)

### 1. Настройка ngrok
```bash
# Регистрация на ngrok.com
# Получи токен: https://dashboard.ngrok.com/get-started/your-authtoken

# Установи токен
ngrok config add-authtoken YOUR_NGROK_TOKEN

# Запусти туннель
ngrok http 8000 --region us
```

### 2. Получение публичного URL
После запуска ngrok покажет URL вида: `https://abc123.ngrok.io`

### 3. Обновление конфигурации
В файле `chatgpt_openapi.json` замени:
```json
"url": "https://YOUR_NGROK_URL_HERE.ngrok.io"
```
На реальный URL от ngrok

---

## Альтернативные варианты публичного доступа

### 🌐 1. Railway (бесплатный хостинг)
```bash
# Установка Railway CLI
npm install -g @railway/cli

# Деплой проекта
railway login
railway init
railway up
```

### 🐳 2. Heroku
```bash
# Установка Heroku CLI
# Создание приложения
heroku create your-amocrm-app
git push heroku main
```

### ☁️ 3. Cloud Run (Google Cloud)
```bash
# Создание Docker image
# Деплой в Cloud Run
```

---

## 🧪 Тестирование Custom GPT

После настройки протестируй:

1. **"Покажи статус сервера"** - должен вернуть JSON со статусом
2. **"Получи 3 сделки"** - проверь работу с entities API
3. **"Создай тестовую сделку"** - протестируй создание записей

---

## 🔧 Устранение проблем

### Ошибка подключения
- Проверь, что сервер запущен
- Убедись что URL в schema правильный
- Проверь firewall и сетевые настройки

### Ошибки авторизации
- Настрой `AMOCRM_ACCESS_TOKEN` в `.env`
- Проверь права доступа в AmoCRM

### Ngrok проблемы  
- Проверь аутентификацию: `ngrok --version`
- Обновляй URL при каждом перезапуске
- Используй постоянные домены в платной версии
